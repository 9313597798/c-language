#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char name[30];
    printf("enter a name\n");
    scanf("%s",name);
}