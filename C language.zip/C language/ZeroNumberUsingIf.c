#include<stdio.h>
void main()
{
    int a;
    printf("Enter a Number");
    scanf("%d",&a);

    if(a==0)
    {
        printf("the number is zero");
    }
}