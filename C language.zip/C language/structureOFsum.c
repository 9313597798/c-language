#include<stdio.h>
#include<conio.h>
typedef struct sum
{
    int rollno;
    int bme,pps,bee;

};

void main()
{


}