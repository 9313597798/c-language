list.deleteLast();
        // list.printList();