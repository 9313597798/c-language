import java.util.Scanner;
public class java {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a char");
        String  vowels=sc.nextLine();
        {
            switch(vowels)
            {
                case "a" :
                    
                    System.out.println("vowels");
                    
                    break;
                case "i" :
                    
                    System.out.println("vowels");
                    
                    break;
                    case "o" :
                        
                    System.out.println("vowels");
                    
                    break;
                    case "u" :
                        
                    System.out.println("vowels");
                    
                    break;
                    case "e":
                        
                    System.out.println("vowels");
                    
                    break;
                    
                    default :
                       System.out.println("cosnents");
                    
            }
        }
        
    }
    
    
}
