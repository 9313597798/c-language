#include<stdio.h>
#include<conio.h>

void main()
{
    int y=20;
   printf("%d\n",y);
    printf("%d\n", funtion(y));

}
int  funtion(int x)
{
         x=30;
     return x;
}

// #include<stdio.h>
// #include<conio.h>
// void main()
// {
//     int y=20;
//     fun(y);
//     printf("%d",y);

// }
// void fun(int x)
// {
//      x=30;
// }

// #include <stdio.h>
// int main()
// {
//     int i = 5;
//     printf("%d %d %d", i++, i++, i++);//7 6 5
//     return 0;
// }