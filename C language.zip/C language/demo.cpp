#include<iostream>
using namespace std;
int main(){
    cout<<"Hrgl;sk";
    return 0;
}