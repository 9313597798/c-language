#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    int i=0;
    char name[]="krishna";
    while (name[i]!='\0')
    {
        printf("%c",name[i]);
        i++;
    }
    
}