#include<stdio.h>
#include<conio.h>
#include<math.h>

void squarenumber(int);
void main()
{
    int n=2;
    printf("%f",pow(n,2));
    return 0;

}
// void squarenumber(int n)
// {
    
// }
