#include<stdio.h>
#include<conio.h>
void main()
{
    int age;
    printf("Enter a your age");
    scanf("%d",&age);
    if(age>=18)
    {
        printf("you can drive");
    }
    else
    {
        printf("ypu can not drive");
    }


}