#include<stdio.h>
void main()
{
    float x,y;
    printf("Enter a value of X");
    scanf("%f",&x);
    y=(3*x*x*x)-(4*x)+32;
    printf("the value of Y is %f",y);
    return 0;

}