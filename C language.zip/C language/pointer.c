#include<stdio.h>
#include<conio.h>
void main()
{
    int a=39;
    int *ptr1,*ptr2;
     
    int *ptr=&a;
    
    printf("%d\n",&a);
    printf("%d\n",&ptr);
    printf("%p\n",*ptr);
    printf("%d\n",ptr);
    printf("%d\n",a);
    printf("%d",ptr1);
    printf("%d",*ptr1);
   

}