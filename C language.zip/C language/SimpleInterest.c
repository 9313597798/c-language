// #include<stdio.h>
// void main()
// {
//     float p,r,n;
//     float simpleinterest;
//     printf("Enter a Value of P and N and R\n");
//     scanf("%f %f %f",&p,&r,&n);
//     simpleinterest = (p*r*n)/100;
//     printf("the simple interest is %f :",simpleinterest);

// }
#include<stdio.h>
int main(){
    int a,b;
    scanf("%d %d",&a,&b);
    printf("Hello");
    printf("%d",a+b);
    return 0;
}