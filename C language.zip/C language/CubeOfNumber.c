#include<stdio.h>
void main()
{
    int x;
    printf("Enter a Number");
    scanf("%d",&x);
    printf("the cube of number is %d:",x*x*x);
}