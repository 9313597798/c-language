#include<stdio.h>
#include<conio.h>
void printHello();
void printGoodbye();
void main()
{
    printHello();
    printGoodbye();
    printHello();
    printGoodbye();
}
void printHello()
{
    printf("Hello\n");
}
void printGoodbye()
{
    printf("Goodbye\n");

}