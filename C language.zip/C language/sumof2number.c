#include <stdio.h>
#include<conio.h>

int main()
{
    int a;
    int b;
    printf("Enter a Number a ");

    scanf("%d",&a);
    printf("enter a Number b ");
    scanf("%d",&b);
    int c=a+b;
    printf(" Sum Of two Number %d :",c);
    return 0;
}






