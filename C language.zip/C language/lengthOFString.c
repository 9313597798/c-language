#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    int i=0;
    char name[30];
    scanf("%s",&name);
    while (name[i]!='\0')
    {
        i++;
       
    }
     printf("%d",i);
    
}

// #include<stdio.h>
// #include<conio.h>
// void main()
// {
//     char name[30];
//     printf("enter a name");
//     scanf("%s", &name);
//     printf("%s",name);
//     int x=length(name);
//     printf("%d",x);
// }pending