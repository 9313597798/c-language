#include<stdio.h>
#include<conio.h>
void main()
{
    int a;
    printf("Enter a Number\n");
    scanf("%d",&a);
    if(a>=0)
    {
        printf("number is positive");

    }
    if(a<0)
    {
        printf("number is negetive");

    }
    
}